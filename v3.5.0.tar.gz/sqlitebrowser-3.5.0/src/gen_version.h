#ifndef GEN_VERSION_H
#define GEN_VERSION_H
#define APP_VERSION "3.5.0"
#define MAJOR_VERSION 3
#define MINOR_VERSION 5
#define PATCH_VERSION 0
#endif
